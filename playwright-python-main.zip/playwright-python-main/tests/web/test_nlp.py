import os

import allure
import pytest
from faker import Faker
from playwright.sync_api import Page, expect

from pages.page_manager import PageManager
from rift.rift_processor import rift_ai


@allure.title("Complete Checkout Using AI")
@allure.description("This test attempts to completes checkout using ai")
@allure.tag("UI", "POSITIVE", "AI")
@allure.severity(allure.severity_level.NORMAL)
@pytest.mark.webtest
def test_checkout_order(page: Page, pm: PageManager) -> None:

    faker = Faker()

    rift_ai('open https://www.saucedemo.com', page)
    rift_ai("enter 'standard_user' into the username input", page)
    rift_ai("type 'secret_sauce' into the password input", page)
    rift_ai("click on the login input", page)

    rift_ai(f"verify the page title is 'Swag Labs'", page)
    rift_ai(f"assert the url contains '{os.getenv('BASE_URL')}/inventory.html'", page)

    rift_ai("click on the 'Add to cart' button", page)
    rift_ai("click on the shopping_cart_link link", page)
    rift_ai("click on the checkout button", page)

    rift_ai(f"enter '{faker.first_name()}' into the first name input", page)
    rift_ai(f"fill '{faker.last_name()}' into the last name input", page)
    rift_ai(f"fill '{faker.last_name()}' into the postalcode input", page)
    rift_ai("click on the continue input", page)
    rift_ai("click on the finish button", page)
    rift_ai("verify the text 'Thank you for your order!' is present on the page", page)

    png_bytes = rift_ai("take screenshot", page)

    allure.attach(
        png_bytes,
        name="order has been placed successfully.",
        attachment_type=allure.attachment_type.PNG
    )


@allure.title("Completes Practice Form Using AI")
@allure.description("This test attempts to completes the form using ai")
@allure.tag("UI", "POSITIVE", "AI")
@allure.severity(allure.severity_level.NORMAL)
@pytest.mark.webtest
def test_practice_form(page: Page, pm: PageManager) -> None:

    page.set_default_timeout(60000)
    faker = Faker()

    rift_ai('open https://demoqa.com/automation-practice-form', page)
    rift_ai(f"enter '{faker.first_name()}' into firstName input", page)
    rift_ai(f"enter '{faker.last_name()}' into lastName input", page)
    rift_ai(f"enter '{faker.email()}' into userEmail input", page)
    rift_ai(f"click on the Male label", page)

    png_bytes = rift_ai("take screenshot", page)

    allure.attach(
        png_bytes,
        name="form has been filled successfully.",
        attachment_type=allure.attachment_type.PNG
    )
