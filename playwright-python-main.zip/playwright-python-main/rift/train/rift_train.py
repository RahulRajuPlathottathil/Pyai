import os
import random
import time
import spacy
from spacy.training import Example
from concurrent.futures import ThreadPoolExecutor, as_completed

# Import your custom data generators
from rift.train.generator.rift_check_data_gen import get_check_training_data
from rift.train.generator.rift_click_data_gen import get_click_training_data
from rift.train.generator.rift_open_data_gen import get_open_training_data
from rift.train.generator.rift_screenshot_data_gen import get_screenshot_training_data
from rift.train.generator.rift_text_data_gen import get_text_training_data
from rift.train.generator.rift_type_data_gen import get_type_training_data
from rift.train.generator.rift_verify_data_gen import get_verify_training_data
from utils.helper import project_root

# configs for training
train_fresh = True
max_training_data_limit = 200
max_iterations = 50
rift_model = f"{project_root}/rift/rift_model_v2"


TRAIN_DATA = []

TRAIN_DATA.extend(get_type_training_data(max_training_data_limit))
TRAIN_DATA.extend(get_click_training_data(max_training_data_limit))
TRAIN_DATA.extend(get_open_training_data(max_training_data_limit))
TRAIN_DATA.extend(get_verify_training_data(max_training_data_limit))
TRAIN_DATA.extend(get_screenshot_training_data())
TRAIN_DATA.extend(get_check_training_data(max_training_data_limit))
TRAIN_DATA.extend(get_text_training_data(max_training_data_limit))


if train_fresh:
    print("starting a new training...")
    # Load a blank English model
    nlp = spacy.blank('en')
    ner = nlp.add_pipe('ner', last=True)
    # Optimizer
    optimizer = nlp.begin_training()
else:
    print('resume the training...')
    nlp = spacy.load(rift_model)
    ner = nlp.get_pipe("ner")
    optimizer = nlp.resume_training()


# Add custom entity labels
labels = ["COMMAND", "VALUE", "FIELD", "TYPE"]
for label in labels:
    ner.add_label(label)


# Define a function to train on a batch of examples
def train_on_batch(batch, nlp_train):
    train_losses = {}
    examples = [Example.from_dict(nlp_train.make_doc(text), annotations) for text, annotations in batch]
    nlp_train.update(examples, sgd=optimizer, losses=train_losses, drop=0.3)
    return train_losses


# Capture overall training time
overall_start_time = time.time()
iteration_times = []  # To store time taken for each iteration

batch_size = 8  # Set an appropriate batch size
num_threads = max(1, int(os.cpu_count()))

# Train the NER model
for i in range(max_iterations):
    iteration_start_time = time.time()
    random.shuffle(TRAIN_DATA)
    overall_losses = {"ner": 0.0}

    for j in range(0, len(TRAIN_DATA), batch_size):
        batch = TRAIN_DATA[j:j + batch_size]
        losses = train_on_batch(batch, nlp)
        overall_losses["ner"] += losses.get("ner", 0.0)

    iteration_end_time = time.time()
    iteration_time = iteration_end_time - iteration_start_time
    iteration_times.append(iteration_time)

    # Calculate average time per iteration
    avg_iteration_time = sum(iteration_times) / len(iteration_times)

    # Estimate time remaining
    remaining_iterations = max_iterations - (i + 1)
    estimated_time_remaining = remaining_iterations * avg_iteration_time

    # Convert time remaining to hours, minutes, and seconds
    hrs, rem = divmod(estimated_time_remaining, 3600)
    mins, secs = divmod(rem, 60)

    print(f"Iteration {i + 1} completed. Overall Loss: {overall_losses['ner']:.4f}. "
          f"Iteration Time: {iteration_end_time - iteration_start_time:.2f} seconds.")

    print(f"Estimated Time Remaining: {int(hrs)}h {int(mins)}m {int(secs)}s")

# Save the trained model
nlp.to_disk(rift_model)
print(f"Model saved to {rift_model}")
