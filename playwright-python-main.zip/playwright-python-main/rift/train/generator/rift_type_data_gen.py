import json
import random

from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]["type_commands"]
values = ['hello', 'world123#', 'test', 'data', 'user123']
fields = ['search', 'firstName', 'First Name', 'FirsT1 NaMe 123#', 'first-name', 'first_name']
input_types = ['input', 'box', 'input field', 'text box', 'text field', 'input box']

TRAIN_DATA = []

def get_type_training_data(max_training_data_limit: int):
    for _ in range(max_training_data_limit):

        command = random.choice(commands)
        value = random.choice(values)
        field = random.choice(fields)
        input_type = random.choice(input_types)

        # Variations for field types
        variations = [
            f"{command} '{value}' into the {field} {input_type}",
            f"{command} '{value}' into {field}",
            f"{command} the {field} {input_type} with '{value}'"
        ]

        # Add unique combinations to training data
        for variation in variations:
            # Calculate the entity indices based on the variation string
            command_start = 0
            command_end = len(command)
            value_start = variation.find(value)
            value_end = value_start + len(value)
            field_start = variation.find(field)
            field_end = field_start + len(field)
            type_start = variation.find(input_type)
            type_end = type_start + len(input_type)

            # Ensure indices are valid (i.e., not -1 or negative)
            if value_start != -1 and field_start != -1 and type_start != -1:
                # Append training data
                TRAIN_DATA.append((variation, {'entities': [
                    (command_start, command_end, 'COMMAND'),
                    (value_start, value_end, 'VALUE'),
                    (field_start, field_end, 'FIELD'),
                    (type_start, type_end, 'TYPE')
                ]}))

    return TRAIN_DATA
