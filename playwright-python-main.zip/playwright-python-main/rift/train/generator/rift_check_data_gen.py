import random
import json

from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]["check_commands"]
fields = ['login', 'submit', 'register', 'continue', 'save', 'confirm', 'apply', 'login-lnk', 'lgn-btn',
          'login_lnk', 'lgn_btn', 'save to proceed', 'edit and continue']
values = ['agree', 'terms and conditions', 'abc-123', 'abc_123', 'abc-12#', 'abc_12#']
types = ['input']

# Generate training data
TRAIN_DATA = []


def get_check_training_data(max_training_data_limit: int):
    for _ in range(max_training_data_limit):
        command = random.choice(commands)
        value = random.choice(values)
        field = random.choice(fields)
        type_ = random.choice(types)

        # Generate variations
        variations = [
            f"{command.lower()} the {field} {type_}",
            f"{command.lower()} the {field} {value} {type_}",
        ]

        # Add unique combinations to training data
        for variation in variations:
            # Calculate the entity indices based on the variation string
            command_start = 0
            command_end = len(command)
            field_start = variation.find(field)
            field_end = field_start + len(field)
            type_start = variation.find(type_)
            type_end = type_start + len(type_)

            # Ensure indices are valid (i.e., not -1 or negative)
            if field_start != -1 and type_start != -1:

                entities = [
                    (command_start, command_end, 'COMMAND'),
                    (field_start, field_end, 'FIELD'),
                    (type_start, type_end, 'TYPE')
                ]

                # Add field only if present
                value_start = variation.find(value)
                if value_start != -1:
                    value_end = value_start + len(value)
                    entities.append((value_start, value_end, 'VALUE'))

                # Append the variation and entities to TRAIN_DATA
                TRAIN_DATA.append((variation, {'entities': entities}))

    return TRAIN_DATA
