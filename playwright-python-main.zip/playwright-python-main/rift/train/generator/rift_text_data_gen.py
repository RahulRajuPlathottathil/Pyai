import json
import random

from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]["text_commands"]
fields = ['search', 'user_name', 'first-name', 'add to cart', 'view more']
element_types = ['input', 'button', 'div', 'h1']


TRAIN_DATA = []

def get_text_training_data(max_training_data_limit: int):

    for _ in range(max_training_data_limit):

        command = random.choice(commands)
        field = random.choice(fields)
        element_type = random.choice(element_types)

        # Variations for search-related fields
        variations = [
            f"{command} from the {field} {element_type}",
            f"{command} of the {field} {element_type}",
            f"{command} from {field} {element_type}",
            f"{command} of {field} {element_type}",
        ]

        # Add unique combinations to training data
        for variation in variations:
            # Calculate the entity indices based on the variation string
            command_start = 0
            command_end = len(command)
            field_start = variation.find(field)
            field_end = field_start + len(field)
            element_type_start = variation.find(element_type)
            element_type_end = element_type_start + len(element_type)

            if field_start != -1 and element_type_start != -1:

                entities = [
                    (command_start, command_end, 'COMMAND'),
                    (field_start, field_end, 'FIELD'),
                    (element_type_start, element_type_end, 'TYPE')
                ]

                # Append the variation and entities to TRAIN_DATA
                TRAIN_DATA.append((variation, {'entities': entities}))

    return TRAIN_DATA
