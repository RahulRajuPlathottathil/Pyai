import json
import random

from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]["screenshot_commands"]


TRAIN_DATA = []

def get_screenshot_training_data(max_training_data_limit=7):

    for _ in range(max_training_data_limit):

        command = random.choice(commands)

        # Variations for search-related fields
        variations = [
            f"{command}",
        ]

        # Add unique combinations to training data
        for variation in variations:
            # Calculate the entity indices based on the variation string
            command_start = 0
            command_end = len(command)

            entities = [
                (command_start, command_end, 'COMMAND')
            ]

            # Append the variation and entities to TRAIN_DATA
            TRAIN_DATA.append((variation, {'entities': entities}))

    return TRAIN_DATA
