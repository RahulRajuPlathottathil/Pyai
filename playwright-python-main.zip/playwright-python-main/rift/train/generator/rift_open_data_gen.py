import json
import random

from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]["open_commands"]
values = ['https://www.google.com/', 'https://yahoo.com', 'http://gmail.com', 'http://gmail.com/', "/search?query=abc&date=%%"]

# Generate training data
TRAIN_DATA = []


def get_open_training_data(max_training_data_limit: int):
    for _ in range(max_training_data_limit):
        command = random.choice(commands)
        value = random.choice(values)

        # Generate variations
        variations = [
            f"{command.lower()} {value}",
        ]

        # Add unique combinations to training data
        for variation in variations:
            # Calculate the entity indices based on the variation string
            command_start = 0
            command_end = len(command)
            value_start = variation.find(value)
            value_end = value_start + len(value)

            # Ensure indices are valid (i.e., not -1 or negative)
            if value_start != -1:
                # Append training data
                TRAIN_DATA.append((variation, {'entities': [
                    (command_start, command_end, 'COMMAND'),
                    (value_start, value_end, 'VALUE'),
                ]}))

    return TRAIN_DATA
