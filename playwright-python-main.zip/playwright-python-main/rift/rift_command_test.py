import spacy
from faker import Faker

from utils.helper import project_root

faker = Faker()

# Load the saved model
nlp_custom = spacy.load(f"{project_root}/rift/rift_model_v2")

input_texts = [
    "navigate to /automation-practice-form/",
    "click on the checkout button",
    f"verify the text 'Thank you for your order!' is present on the page",
    f"enter '{faker.first_name()}' into the first name input",
    "type 'secret_sauce' into password input",
    "click on the male label"
]

# Test the custom NER model on a new sentence

for input_text in input_texts:

    doc = nlp_custom(input_text)

    # Initialize variables to hold the extracted entities
    command = None
    value = None
    field = None
    type_ = None

    # Iterate through detected entities and assign to variables
    for ent in doc.ents:
        if ent.label_ == "COMMAND":
            command = ent.text
        elif ent.label_ == "VALUE":
            value = ent.text
        elif ent.label_ == "FIELD":
            field = ent.text
        elif ent.label_ == "TYPE":
            type_ = ent.text

    # Print the extracted entities
    print(f"TEXT - {input_text}")
    print(f"COMMAND - {command}")
    print(f"VALUE - {value}")
    print(f"FIELD - {field}")
    print(f"TYPE - {type_}")

