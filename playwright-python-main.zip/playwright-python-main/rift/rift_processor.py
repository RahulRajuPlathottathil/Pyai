import json

import spacy
from playwright.sync_api import Page, expect

from rift.locator import find_locator, text_present
from utils.helper import project_root

with open(f"{project_root}/rift/config.json", 'r') as f:
    config = json.load(f)

commands = config["commands"]

nlp_custom = spacy.load(f"{project_root}/rift/rift_model_v2")


# Function to process the command and extract information
# reflections intelligent functional tester AI
def rift_ai(rift_command: str, page: Page):
    doc = nlp_custom(rift_command)

    command = None
    value = None
    field = None
    type_ = None

    for ent in doc.ents:
        if ent.label_ == "COMMAND":
            command = ent.text.lower()
        elif ent.label_ == "VALUE":
            value = ent.text
        elif ent.label_ == "FIELD":
            field = ent.text
        elif ent.label_ == "TYPE":
            type_ = ent.text

    open_commands = commands["open_commands"]
    type_commands = commands["type_commands"]
    click_commands = commands["click_commands"]
    verify_commands = commands["verify_commands"]
    screenshot_commands = commands["screenshot_commands"]
    check_commands = commands["check_commands"]
    text_commands = commands["text_commands"]

    if command in open_commands:
        return page.goto(value)
    elif command in type_commands:
        return find_locator(page, 'input', field).fill(value)
    elif command in click_commands:
        if value not in [None, '']:
            return find_locator(page, type_, value).click()
        return find_locator(page, type_, field, value).click()
    elif command in verify_commands:
        if 'page title' in rift_command.lower():
            expect(page).to_have_title(value)
        elif 'url contains' in rift_command.lower():
            expect(page).to_have_url(value)
        elif 'is present on the page' in rift_command.lower():
            is_present = text_present(page, value)
            assert is_present
    elif command in screenshot_commands:
        return page.screenshot()